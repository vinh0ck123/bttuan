package com.uth.thuvienapp

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.LibraryBooks
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.uth.thuvienapp.ui.theme.ThuVienAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ThuVienAppTheme {
                val viewModel = remember { ThuVienViewModel() }
                var selectedTab by remember { mutableStateOf(0) }

                Scaffold(
                    containerColor = Color.White,
                    bottomBar = {
                        NavigationBar {
                            NavigationBarItem(
                                selected = selectedTab == 0,
                                onClick = { selectedTab = 0 },
                                icon = { Icon(Icons.Default.Home, contentDescription = "Trang chủ") },
                                label = { Text("Trang chủ") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 1,
                                onClick = { selectedTab = 1 },
                                icon = { Icon(Icons.Default.LibraryBooks, contentDescription = "Sách") },
                                label = { Text("Sách") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 2,
                                onClick = { selectedTab = 2 },
                                icon = { Icon(Icons.Default.Person, contentDescription = "Độc giả") },
                                label = { Text("Độc giả") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 3,
                                onClick = { selectedTab = 3 },
                                icon = { Icon(Icons.Default.MenuBook, contentDescription = "Mượn trả") },
                                label = { Text("Mượn trả") }
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        when (selectedTab) {
                            0 -> TrangChuScreen()
                            1 -> SachScreen(viewModel)
                            2 -> DocGiaScreen(viewModel) { selectedTab = 3 }
                            3 -> MuonTraScreen(viewModel)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TrangChuScreen() {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = "Trang chủ", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = "Ứng dụng Quản lý Thư viện - Demo", color = Color.Gray)
    }
}

@Composable
fun SachScreen(viewModel: ThuVienViewModel) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(text = "Danh sách Sách", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(12.dp))
        LazyColumn {
            items(viewModel.dsSach.size) { i ->
                val s = viewModel.dsSach[i]
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), shape = RoundedCornerShape(12.dp)) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(s.ten, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.weight(1f))
                        Text("Tác giả: ${s.tacGia}", color = Color.Gray)
                    }
                }
            }
        }
    }
}

@Composable
fun DocGiaScreen(viewModel: ThuVienViewModel, onSelectTab: () -> Unit) {
    val context = LocalContext.current
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(text = "Danh sách Độc giả", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(12.dp))
        LazyColumn {
            items(viewModel.dsSinhVien.size) { i ->
                val sv = viewModel.dsSinhVien[i]
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), shape = RoundedCornerShape(12.dp)) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text(sv.ten, fontWeight = FontWeight.SemiBold)
                            Text("Lớp: ${sv.lop}", color = Color.Gray)
                        }
                        Spacer(Modifier.weight(1f))
                        Button(onClick = {
                            viewModel.sinhVienDangChon = sv
                            Toast.makeText(context, "Đã chọn ${'$'}{sv.ten}", Toast.LENGTH_SHORT).show()
                            onSelectTab()
                        }) {
                            Text("Chọn")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MuonTraScreen(viewModel: ThuVienViewModel) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(text = "Mượn trả", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(12.dp))
        viewModel.sinhVienDangChon?.let { sv ->
            Text(text = "Sinh viên: ${'$'}{sv.ten} (${'$'}{sv.lop})", fontSize = 18.sp, fontWeight = FontWeight.Medium)
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = "Sách đã mượn:", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            LazyColumn {
                items(sv.sachMuon.size) { i ->
                    val s = sv.sachMuon[i]
                    Text("- ${'$'}{s.ten} (${'$'}{s.tacGia})")
                }
            }
        } ?: Text("Chưa chọn sinh viên nào", color = Color.Gray)
    }
}
