package com.uth.thuvienapp.ui.theme

import androidx.compose.ui.graphics.Color

val md_theme_light_primary = Color(0xFF1E88E5)
val md_theme_light_onPrimary = Color(0xFFFFFFFF)
val md_theme_light_background = Color(0xFFFFFFFF)
