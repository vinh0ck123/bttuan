package com.uth.thuvienapp

data class Sach(val ten: String, val tacGia: String)
data class SinhVien(val ten: String, val lop: String, val sachMuon: List<Sach> = emptyList())
