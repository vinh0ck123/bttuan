package com.uth.thuvienapp

import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue

class ThuVienViewModel {
    val dsSach = listOf(
        Sach("Lập trình Kotlin", "Nguyễn Văn A"),
        Sach("Cấu trúc dữ liệu", "Trần Thị B"),
        Sach("Cơ sở dữ liệu", "Lê Văn C")
    )
    val dsSinhVien = listOf(
        SinhVien("Nguyễn Văn Nam", "DHKTPM18A", listOf(dsSach[0], dsSach[1])),
        SinhVien("Trần Thị Hoa", "DHKTPM18B", listOf(dsSach[2])),
        SinhVien("Lê Quốc Khánh", "DHKTPM18C", listOf())
    )

    var sinhVienDangChon: SinhVien? by mutableStateOf(null)
}
