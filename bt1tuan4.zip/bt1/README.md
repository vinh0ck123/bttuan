ThuVienApp - Full package (Narwhal 2025.1.4)

Package: com.uth.thuvienapp

How to use:
1. Unzip ThuVienApp_full_package.zip
2. Open in Android Studio Narwhal (File -> Open) selecting the root folder
3. Let IDE sync Gradle (it will download Gradle 8.9 via wrapper)
4. Run on emulator or device

Notes:
- gradle-wrapper.jar is a placeholder; Android Studio will download Gradle distribution when running wrapper.
