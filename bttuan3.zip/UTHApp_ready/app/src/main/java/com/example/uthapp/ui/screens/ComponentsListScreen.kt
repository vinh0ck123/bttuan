package com.example.uthapp.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

data class UIComponent(val name: String, val description: String, val category: String)

@Composable
fun ComponentsListScreen(navController: NavController) {
    val components = listOf(
        UIComponent("Text", "Displays text", "Display"),
        UIComponent("Image", "Displays an image", "Display"),
        UIComponent("TextField", "Input field for text", "Input"),
        UIComponent("PasswordField", "Input field for passwords", "Input"),
        UIComponent("Column", "Arranges elements vertically", "Layout"),
        UIComponent("Row", "Arranges elements horizontally", "Layout"),
    )

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Text(
                text = "UI Components List",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )

            Spacer(modifier = Modifier.height(16.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                val grouped = components.groupBy { it.category }

                grouped.forEach { (category, items) ->
                    item {
                        Text(
                            text = category,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    }

                    items(items) { component ->
                        ComponentCard(component = component, onClick = {
                            navController.navigate("detail/${component.name}")
                        })
                    }
                }
            }
        }
    }
}

@Composable
fun ComponentCard(component: UIComponent, onClick: () -> Unit) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        color = Color(0xFFBBDEFB),
        shape = MaterialTheme.shapes.medium,
        shadowElevation = 2.dp
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp)
        ) {
            Text(
                text = component.name,
                fontSize = 18.sp,
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = component.description,
                color = Color.DarkGray
            )
        }
    }
}
