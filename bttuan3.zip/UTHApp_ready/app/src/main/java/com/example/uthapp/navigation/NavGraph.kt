package com.example.uthapp.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.navigation.NavType
import com.example.uthapp.ui.screens.*

sealed class Screen(val route: String) {
    object Welcome : Screen("welcome")
    object ComponentsList : Screen("componentsList")
    object Detail : Screen("detail/{name}") {
        fun createRoute(name: String) = "detail/$name"
    }
}

@Composable
fun NavGraph(navController: NavHostController = rememberNavController()) {
    NavHost(
        navController = navController,
        startDestination = Screen.Welcome.route
    ) {
        composable(Screen.Welcome.route) {
            WelcomeScreen(navController)
        }
        composable(Screen.ComponentsList.route) {
            ComponentsListScreen(navController)
        }
        composable(
            route = "detail/{name}",
            arguments = listOf(navArgument("name") { type = NavType.StringType })
        ) { backStackEntry ->
            val name = backStackEntry.arguments?.getString("name") ?: ""
            ComponentDetailScreen(name = name, navController = navController)
        }
    }
}
