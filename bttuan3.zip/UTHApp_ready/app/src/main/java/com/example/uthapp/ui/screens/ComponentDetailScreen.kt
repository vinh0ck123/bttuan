package com.example.uthapp.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@Composable
fun ComponentDetailScreen(name: String, navController: NavController) {
    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "$name Detail", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(24.dp))
            when (name) {
                "Text" -> {
                    Text("The quick ", style = MaterialTheme.typography.bodyLarge)
                    Text("Brown ", fontWeight = FontWeight.Bold, fontSize = 28.sp)
                    Text("fox jumps over ", fontStyle = FontStyle.Italic)
                    Text("the lazy dog.", style = MaterialTheme.typography.bodyLarge)
                }
                "Image" -> {
                    Text("Image component - shows local UTH images", style = MaterialTheme.typography.bodyLarge)
                }
                else -> {
                    Text("Detail for: $name", style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
    }
}
