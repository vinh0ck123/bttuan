package com.example.uthapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.uthapp.navigation.NavGraph
import com.example.uthapp.ui.theme.UTHAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            UTHAppTheme {
                NavGraph()
            }
        }
    }
}
