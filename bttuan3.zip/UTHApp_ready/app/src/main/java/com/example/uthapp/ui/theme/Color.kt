package com.example.uthapp.ui.theme

import androidx.compose.ui.graphics.Color

val md_theme_light_primary = Color(0xFF0057B8)
val md_theme_light_onPrimary = Color(0xFFFFFFFF)
val md_theme_light_secondary = Color(0xFF03DAC6)
val md_theme_light_onSecondary = Color(0xFF000000)
val md_theme_light_background = Color(0xFFFFFFFF)
