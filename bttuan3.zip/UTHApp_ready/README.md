UTHApp - Compose sample. Open in Android Studio and Run.
