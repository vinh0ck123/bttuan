Bài 1: Mong muốn và định hướng sau khi học xong môn học

Mong muốn nắm vững kiến thức cơ bản về lập trình di động trên Android 

Có thể tự xây dựng ứng dụng đơn giản phục vụ học tập hoặc nhu cầu cá nhân

Định hướng học thêm về Firebase, API, và các công nghệ hỗ trợ backend cho ứng dụng di động

Mong muốn tham gia các dự án thực tế hoặc thực tập tại công ty phần mềm để nâng cao kỹ năng

Mục tiêu dài hạn là trở thành lập trình viên mobile chuyên nghiệp, có thể phát triển ứng dụng đa nền tảng (Android/iOS)

Quan tâm đến các công nghệ như Flutter, React Native để mở rộng cơ hội nghề nghiệp




Bài 2: Lập trình di động có phát triển trong 10 năm tới không?

Theo em, lập trình di động sẽ tiếp tục phát triển mạnh trong 10 năm tới

Smartphone ngày càng phổ biến và trở thành thiết bị không thể thiếu trong đời sống hàng ngày

Các dịch vụ như ngân hàng, giáo dục, y tế, mua sắm đều chuyển sang nền tảng di động để tiếp cận người dùng nhanh hơn

Công nghệ mới như AI, AR/VR, IoT đang được tích hợp vào ứng dụng di động, mở ra nhiều cơ hội mới

Nhu cầu tuyển dụng lập trình viên mobile vẫn rất cao, cả trong nước và quốc tế

Vì vậy, học lập trình di động là lựa chọn phù hợp với xu thế công nghệ hiện nay
