package com.example.myapplication

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ThucHanh01UI()
        }
    }
}

@Composable
fun ThucHanh01UI() {
    var name by remember { mutableStateOf(TextFieldValue("")) }
    var age by remember { mutableStateOf(TextFieldValue("")) }
    var result by remember { mutableStateOf("") }

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        color = Color(0xFFFDFDFD)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // ====== Khung tiêu đề ======
            Card(
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(3.dp, Color(0xFF4A5568)), // viền đậm
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier
                    .fillMaxWidth(0.9f)
                    .height(120.dp)
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "THỰC HÀNH 01",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF2D3748),
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.height(40.dp))

            // ====== Ô nhập họ tên ======
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Họ và tên") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(0.9f)
            )

            Spacer(modifier = Modifier.height(20.dp))

            // ====== Ô nhập tuổi ======
            OutlinedTextField(
                value = age,
                onValueChange = { age = it },
                label = { Text("Tuổi") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(0.9f)
            )

            Spacer(modifier = Modifier.height(30.dp))

            // ====== Nút xử lý ======
            Button(
                onClick = {
                    val nameText = name.text.trim()
                    val ageValue = age.text.trim().toIntOrNull()

                    if (nameText.isEmpty() || ageValue == null || ageValue < 0) {
                        result = "Vui lòng nhập hợp lệ!"
                    } else {
                        val category = when {
                            ageValue <= 2 -> "Em bé"
                            ageValue <= 6 -> "Trẻ em"
                            ageValue <= 65 -> "Người lớn"
                            else -> "Người già"
                        }

                        result = "Họ tên: $nameText\nTuổi: $ageValue\nPhân loại: $category"
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4A5568)),
                modifier = Modifier
                    .fillMaxWidth(0.6f)
                    .height(50.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    "Kiểm tra",
                    fontSize = 16.sp,
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(30.dp))

            // ====== Kết quả ======
            if (result.isNotEmpty()) {
                Text(
                    text = result,
                    fontSize = 18.sp,
                    color = Color(0xFF2D3748),
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}
